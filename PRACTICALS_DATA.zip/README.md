# Gene2farm WinterSchool 2015
This is a temporary Gene2farm Winter School git page for participants only.

Here you'll find the samll dataset used for my practicals.

To clone this repository:

   `git clone https//github.com/nicolazzie/WS2015.git`
