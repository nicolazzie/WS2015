out=./HELPFILE.txt
cdir=`pwd`

echo > $out
echo "This is a help file for G2FWS2015 practicals ">> $out
echo >> $out
echo >> $out
echo "####### We clone a repository with a bunch of useful tools to remap, convert formats and allele codings of files. " >> $out
echo "git clone https://github.com/nicolazzie/SNPChimpRepo.git " >> $out
echo "cd SNPChimpRepo" >> $out
echo " " >> $out
echo "####### We access the PEDDA_MATRIX folder and edit the parameter file of the program " >> $out
echo "####### PEDDA_MATRIX converts the format from Illumina MATRIX to PLINK. " >> $out
echo "cd PEDDA_MATRIX " >> $out
echo "gedit peddam.param  " >> $out
echo " " >> $out
echo "### HELP: ABSOLUTE PATHS FOR PEDDA_MATRIX - COPY from ###> onwards and paste in the relative variable " >> $out
echo "### FINREP: ###> $cdir/FinalReport_MATRIX.csv " >> $out
echo "### SNPMAP: ###> $cdir/SnpMap_MATRIX.csv " >> $out
echo "### OUTNAME:###> $cdir/PLINK_MATRIX_AB " >> $out
echo " " >> $out
echo "python pedda_matrix.py" >> $out
echo " " >> $out
echo "####### We access the PEDDA_ROW folder and edit the parameter file of the program " >> $out
echo "####### PEDDA_ROW converts the format from Illumina ROW to PLINK. " >> $out
echo "cd ../PEDDA_ROW " >> $out
echo "gedit peddar.param  " >> $out
echo " " >> $out
echo "### HELP: ABSOLUTE PATHS FOR PEDDA_ROW - COPY from ###> onwards and paste in the relative variable " >> $out
echo "### FINREP: ###> $cdir/FinalReport_ROW.txt " >> $out
echo "### SNPMAP: ###> $cdir/SnpMap_ROW.txt " >> $out
echo "### OUTNAME:###> $cdir/PLINK_ROW_TOP " >> $out
echo " " >> $out
echo "python pedda_row.py" >> $out
echo " " >> $out
echo "####### We access the iConvert folder and edit the parameter file of the program " >> $out
echo "####### iConvert modifies the allele coding from a PLINK file format and remaps the position - if required " >> $out
echo "cd ../iConvert " >> $out
echo "gedit convert.param  " >> $out
echo " " >> $out
echo "##### STEP1: MATRIX AB to MATRIX TOP and remap " >> $out
echo "### HELP: ABSOLUTE PATHS FOR iConvert  - COPY from ###> onwards and paste in the relative variable " >> $out
echo "### PEDfile:      ###> $cdir/PLINK_MATRIX_AB.ped " >> $out
echo "### MAPfile:      ###> $cdir/PLINK_MATRIX_AB.map " >> $out
echo "### IN_format:    ###> ill_ab " >> $out
echo "### SNPchimp_file:###> $cdir/SNPchimp_FAKEresult_1234567.csv " >> $out
echo " " >> $out
echo "python iConvert.py" >> $out
echo " " >> $out
echo " " >> $out
echo "##### STEP2: PLINK FORWARD TO PLINK TOP and remap " >> $out
echo "gedit convert.param  " >> $out
echo " " >> $out
echo "### HELP: ABSOLUTE PATHS FOR iConvert - COPY from ###> onwards and paste in the relative variable " >> $out
echo "### PEDfile:      ###> $cdir/FinalReport_PLINK.ped " >> $out
echo "### MAPfile:      ###> $cdir/SnpMap_PLINK.map  " >> $out
echo "### IN_format:    ###> ill_forward " >> $out
echo " " >> $out
echo "python iConvert.py" >> $out
echo " " >> $out
echo " " >> $out
echo " " >> $out
echo "####### We now try to divide the 'good' files from the 'original' or working files" >> $out
echo "####### First we go to the WS2015 folder, where all files were directed" >> $out
echo " " >> $out
echo "cd ../.." >> $out
echo "ls" >> $out
echo "### Now we create a folder where we will put all the 'good' files and move them in there" >> $out
echo "mkdir FINAL_FILES" >> $out
echo "mv *_updated* PLINK_ROW_TOP.* FINAL_FILES/" >> $out
echo " " >> $out
echo "####### We now download the Zanardi software" >> $out
echo "git clone https://github.com/bioinformatics-ptp/Zanardi.git" >> $out
echo "cd Zanardi" >> $out
echo "### STEP1: Downloading the useful software" >> $out
echo "python Zanardi.py --download=plink,beagle4" >> $out
echo " " >> $out
echo "### STEP2: Modifying the parameter file to analyse the data" >> $out
echo "gedit PARAMFILE.txt" >> $out
echo " " >> $out
echo "### INPUTped:    ###> $cdir/FINAL_FILES/FinalReport_PLINK_updated.ped,$cdir/FINAL_FILES/PLINK_MATRIX_AB_updated.ped,$cdir/FINAL_FILES/PLINK_ROW_TOP.ped" >> $out 
echo "### INPUTmap:    ###> $cdir/FINAL_FILES/SnpMap_PLINK_updated.map,$cdir/FINAL_FILES/PLINK_MATRIX_AB_updated.map,$cdir/FINAL_FILES/PLINK_ROW_TOP.map" >> $out
echo "### OUTPUT_NAME  ###> WINTERSCHOOL" >> $out
echo " " >> $out
echo "### STEP3: Running the program " >> $out
echo "python Zanardi.py --plinkqc --mds --beagle4 " >> $out
echo " " >> $out
echo " " >> $out
echo "### CONGRATS! IF YOU ARE READING THIS LINE, YOU HAVE SURVIVED THE DAY!" >> $out

gedit $out &
